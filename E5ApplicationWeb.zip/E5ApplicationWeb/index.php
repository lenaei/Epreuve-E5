<?php
session_start();

//connexion a la base

$config = parse_ini_file("base.ini");
try {
	$pdo = new \PDO("mysql:host=" . $config["host"] . ";dbname=" . $config["database"] . ";charset=utf8", $config["user"], $config["password"]);
} catch (Exception $e) {
	echo "<h1>Erreur de connexion à la base de données :</h1>";
	echo $e->getMessage();
	exit;
}

require ("vues/vue.php");
require ("controleurs/controleur.php");
require ("modeles/utilisateurs.php");
require ("modeles/annonces.php");
require ("modeles/logement.php");
require ("modeles/photo.php");
require ("modeles/periode.php");
require ("modeles/reservation.php");
require ("modeles/type.php");

if (isset($_GET["action"])) {

	switch ($_GET["action"]) {
		case "accueil":
			(new controleur)->accueil();
			break;
		case "createanouncement":
			(new controleur)->createanouncement();
			break;
		// case "Apartment":
		// 	(new controleur)->accueil();
		// 	break;
		// case "Mention":
		// 	(new controleur)->mention();
		// 	break;
		case "inscription":
			(new controleur)->inscription();
			break;
		case "connexion":
			(new controleur)->connexion();
			break;
		case "deconnexion":
			(new controleur)->deconnexion();
			break;
		case "annonces":
			(new controleur)->annonces();
			break;
		case "editanouncement":
			(new controleur)->editanouncement();
			break;

		case "afficherMaison":
			(new controleur)->afficherMaison();
			break;
		case "booking":
			(new controleur)->booking();
			break;
		case "profil":
			(new controleur)->profilProprio();
			break;
		case "deleteanouncement":
			(new controleur)->deleteanouncement();
			break;
		case "deleteReservation":
			(new controleur)->deleteReservation();
			break;
		// no working 
		// case "modifier":
		// 	(new controleur)->modifierPeriode();
		// 	break;
		// case "ajouter":
		// 	(new controleur)->ajouterPeriode();
		// 	break;
		// case "supprimer":
		// 	(new controleur)->supprimerPeriode();
		// 	break;


	}

} 
elseif (isset($_GET['filter'])) {
	$getAllType = (new type)->getAllType();
	foreach($getAllType as $type){
		if($type['name']==$_GET['filter']){
			(new controleur)->filtered();
		}
	}
}
elseif (isset($_POST['search']) ){
	(new controleur)->accueil($_POST['search']);

}
else {
	(new controleur)->accueil();
}





?>