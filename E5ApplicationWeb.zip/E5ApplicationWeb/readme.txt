Application web :
Utilisant le langage PHP avec le modèle MVC.

Pour l'installation, il vous suffira de copier le répertoire sur un serveur ou en local, et de le placer dans le répertoire "www" pour WampServer ou "htdocs" pour XAMPP.

Concernant la base de données, elle est déjà hébergée sur mon serveur OVH sous le nom de "booking_system". Les logements devrons donc directement apparaitrent sur l'application. Toutes les informations de connexion à la base de données sont fournies ci-dessous :

URL de connexion à la base de données : https://phpmyadmin-gra.hosting.ovh.net
Serveur : ai117232-001.eu.clouddb.ovh.net:35835
Identifiant : userE5
Mot de passe : User00550002BLD
Rôle : tous
Ainsi, aucune action n'est requise concernant la base de données, cela est déjà géré.

Cependant, par mesure de précaution, le code SQL pour créer la base de données est fourni dans le fichier booking_system.sql. 