<?php
class controleur
{
    public function accueil($search = null)
    {

        $lesAnnonces = array();
        if (isset($_POST['search'])) {
           
            $lesAnnonces =(new annonces)->search($search);
            $type_list = (new type)->getAllType();
            (new vue)->accueil($lesAnnonces, $type_list);
        } else {
            
            $lesAnnonces = (new annonces)->getAllAnnonces();
            $type_list = (new type)->getAllType();
            (new vue)->accueil($lesAnnonces, $type_list);
        }
    }

    public function appartement()
    {
        $lesAnnonces = array();
        $lesAnnonces = (new annonces)->getByType("1");
        $lesPhotos = '';
        $type_list = (new type)->getAllType();

        (new vue)->appartement($lesAnnonces, $type_list);
    }
    public function filtered()
    {
        $lesAnnonces = array();
        $type_id = (new type)->getTypeByName($_GET['filter']);
        $lesAnnonces = (new annonces)->getByType($type_id[0]['id']);
        $lesPhotos = '';
        $type_list = (new type)->getAllType();

        (new vue)->accueil($lesAnnonces, $type_list);
    }


    public function createanouncement()
    {
        if (isset($_SESSION['role']) && $_SESSION['role'] == "employee") {
            if (isset($_POST["ok"])) {
                
                $title = $_POST['title'];
                $description = $_POST['description'];
                $location = $_POST['location'];
                $postal_code = $_POST['postal_code'];
                $type_id = $_POST['type'];
                $image_name = $_FILES['image']['name'];
                $user_id = $_SESSION['user_id'];
                $file = $_FILES["image"];

              
                $fileName = $file["name"];
                $fileTmpName = $file["tmp_name"];
                $fileSize = $file["size"];
                $fileError = $file["error"];

                $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

                $allowedExts = array("jpg", "jpeg", "png", "gif");

                if (in_array($fileExt, $allowedExts)) {
                    
                    $uniqueFileName = "image" . strtotime(date("Y-m-d H:i:s", time())) . "." . $fileExt;
                    $upload_dir = "uploads/" . $uniqueFileName;
                    move_uploaded_file($fileTmpName, $upload_dir);

                    echo "File uploaded successfully.";
                }
                $date = date("Y-m-d");

                if ((new annonces)->ajouterAnnonces($title, $description, $location, $uniqueFileName, $user_id, $date, $type_id, $postal_code)) {
                    header("Location: index.php?action=accueil");
                    exit;
                }

                die();
            } else {
                $type_list = (new type)->getAllType();
                (new vue)->createanouncement($type_list);
            }
        } else {
            (new vue)->login_as_employee_first();
        }
    }

    public function editanouncement()
    {
        if (isset($_POST['ok'])) {
            // echo "inside post";
            if(isset($_GET['annonces_id'])){
                $id = $_GET['annonces_id'];

            }
            $title = $_POST['title'];
            $description = $_POST['description'];
            $location = $_POST['location'];
            $postal_code = $_POST['postal_code'];
            $type_id = $_POST['type'];
            $file = $_FILES["image"];
            $fileName = $file["name"];
            $fileTmpName = $file["tmp_name"];
            $fileSize = $file["size"];
            $fileError = $file["error"];
            $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $allowedExts = array("jpg", "jpeg", "png", "gif");
            $uniqueFileName=null;
            if (in_array($fileExt, $allowedExts)) {
                $uniqueFileName = "image" . strtotime(date("Y-m-d H:i:s", time())) . "." . $fileExt;
                $upload_dir = "uploads/" . $uniqueFileName;
                move_uploaded_file($fileTmpName, $upload_dir);

                echo "File uploaded successfully.";
            }
            if ($uniqueFileName ==null) {

                 (new annonces)->updateAnnonce($id, $title, $description, $location, null, $type_id, $postal_code);
            } else {
                 (new annonces)->updateAnnonce($id, $title, $description, $location, $uniqueFileName, $type_id, $postal_code);

            }
            header("Location: index.php?action=annonces&annonces_id=$id");
        } else {
            $annonces_id = $_GET['annonces_id'];
            $annonces_edit = (new annonces)->getUneAnnonce($annonces_id);
            $type_list = (new type)->getAllType();
            (new vue)->editanouncement($annonces_edit, $annonces_id, $type_list);
        }
    }
    public function deleteanouncement()
    {
        $annonces_id = $_GET['annonces_id'];
        (new annonces)->deleteanouncement($annonces_id);
        (new reservation)->delete($annonces_id);
        header("Location: index.php");
    }
    public function booking()
    {
        $user_id = $_SESSION['user_id'];
        if (isset($_POST)) {
            echo "inside booking";
            $start_date = date("Y-m-d", strtotime($_POST['start_date']));
            $end_date = date("Y-m-d", strtotime($_POST['end_date']));
            $annonces_id = $_GET['annonces_id'];
            echo $annonces_id;
            echo $user_id;
            echo $start_date;
            echo $end_date;

            if ((new reservation)->reserve($annonces_id, $user_id, $start_date, $end_date)) {
                header("Location: index.php?action=annonces&annonces_id=$annonces_id");
            }
        }
    }

    public function deleteReservation()
    {
        $annonces_id = $_GET['annonces_id'];
        (new reservation)->delete($annonces_id);
        if (isset($_GET['action']) && $_GET['action'] == "deleteReservation") {
            header("Location: index.php?action=annonces&annonces_id=$annonces_id");
        }
    }

    public function connexion()
    {
        if (isset($_POST["ok"])) {
            $mdp = $_POST['password'];
            $email = htmlspecialchars($_POST['email']);
            if ((new utilisateurs)->connexion($email, $mdp)) {
                $this->accueil();
            } else {
                $message = 'Mauvais login/mot de passe';
                (new vue)->connexion($message);
            }

        } else {
            (new vue)->connexion();
        }
    }

    public function inscription()
    {
        (new vue)->inscription();
        if (isset($_POST['ok'])) {
            $message = null;
            $name = $_POST['name'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $role = $_POST['role'];
            if (!empty($name && $email && $password && $role)) {
                if ((new utilisateurs)->inscription($name, $email, $password, $role)) {
                    header("Location: index.php?action=connexion");
                } else {
                    $message = "un probleme est survenu lors de l'inscription";
                    (new vue)->inscription($message);
                }
            }
        }

    }

    public function annulerReservationAnnonce($idAnnonce)
    {
        if (isset($_SESSION['connexion'])) {
            $idUtilisateur = $_SESSION['connexion'];
            (new reservation)->annuleReservation($idUtilisateur);
            header("Location: index.php?action=annonce_details&id=$idAnnonce");
            exit;
        } else {
            header("Location: index.php?action=connexion");
            exit;
        }
    }

    public function annonces()
    {

        $annonces_id = $_GET['annonces_id'];
        $uneAnnonce = array();
        $uneReservation = array();
        $annonces = (new annonces)->getUneAnnonce($annonces_id);
        $booking_data = (new reservation)->single_booking_data($annonces_id);
        $current_date = date("Y-m-d");
        if ($booking_data) {
            if ($current_date > $booking_data[0]['end_date']) {
                $this->deleteReservation();
                $booking_data = null;
            }
        }
        if ($booking_data) {
            # code...
            $client_info = (new Utilisateurs)->getInfo($booking_data[0]['client_id']);
            (new vue)->uneAnnonce($annonces, $booking_data, $client_info);
        } else {
            (new vue)->uneAnnonce($annonces, null, null);

        }
    }

    public function afficherAppartement()
    {
        $id = 1;
        $lesLogements = array();
        $lesLogements = (new annonces)->getAnnonces($id);
    }

    public function afficherMaison()
    {
        $id = 2;
        $lesLogements = array();
        $lesPhotos = (new photo)->getAllPhoto();
        $lesLogements = (new annonces)->getAnnonces($id);

    }

    public function profilProprio()
    {
        $utilisateurs = array();
        $annonces = array();
        $user_id = $_SESSION['user_id'];
        $user_data = (new Utilisateurs)->getInfo($user_id);
        (new vue)->profilProprio($user_data);

    }


    public function ajouterPeriode()
    {
        $annonces = array();
        $lesPhotos = (new photo)->getAllPhoto();
        $erreur = null;
        $succes = null;
        $annonces = (new annonces)->getAnnonceProprio($_SESSION['connexion']);


        foreach ($annonces as $annonce) {
            if (isset($_POST[$annonce['ID_Logements']])) {
                $dateDebut = htmlspecialchars($_POST['debutDate']);
                $finDate = htmlspecialchars($_POST['finDate']);
                $prix = htmlspecialchars($_POST['prix']);
                $id = $annonce['ID_Logements'];
                if (empty($prix) || empty($dateDebut) || empty($finDate)) {
                    $erreur = "Veuillez remplir tous les champs !";
                } else {
                    if ($dateDebut > $finDate) {
                        $erreur = "La date de début ne peut pas être supérieur a la date de fin";
                    } else {

                        if ((new periode)->ajouterPeriode($id, $dateDebut, $finDate, $prix)) {
                            $succes = "Periode de réservations bien ajoutée !";
                        } else {
                            $erreur = "Un probleme est survenu";
                        }
                    }
                }
            }
        }
        (new vue)->ajouterPeriode($annonces, $lesPhotos, $erreur, $succes);

    }


    public function deconnexion()
    {
        (new utilisateurs)->deconnexion();
        header('Location: index.php?action=accueil');
    }
}


?>