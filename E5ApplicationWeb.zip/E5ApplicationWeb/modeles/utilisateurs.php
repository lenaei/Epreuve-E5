<?php

class Utilisateurs {
    private $pdo;

    public function __construct() {
        
        try {
            $infoConnexion = parse_ini_file("base.ini");
            $this->pdo = new PDO("mysql:host=".$infoConnexion["host"].";dbname=".$infoConnexion["database"].";charset=utf8", $infoConnexion["user"], $infoConnexion["password"]);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }
    }
    

    public function inscription($name, $email, $password, $role) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $sql = $this->pdo->prepare("INSERT INTO users(name, email, password, role) values(:name, :email, :password, :role)");
        
        $sql->bindParam(':name', $name, PDO::PARAM_STR);
        $sql->bindParam(':email', $email, PDO::PARAM_STR);
        $sql->bindParam(':password', $hash, PDO::PARAM_STR);
        $sql->bindParam(':role', $role, PDO::PARAM_STR);
        return $sql->execute();
        
    }

   

    public function connexion($email, $motDePasse) {

        $stmt = $this->pdo->prepare("SELECT id, email, role, name, password FROM users WHERE email = :email");
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (password_verify($motDePasse, $user['password'])) {
          
            $_SESSION['connexion'] = $user['id'];
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user["role"];
            $_SESSION['user']= $user['name'];
            return true; 
        }

        return false; 
    }

    public function getInfo($id){
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE id = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    

    

    public function deconnexion() {
     
        session_destroy();
        
    }

}

?>
