<?php
class annonces
{
    private $pdo;

    public function __construct()
    {
        try {
            $infoConnexion = parse_ini_file("base.ini");
            $this->pdo = new PDO("mysql:host=" . $infoConnexion["host"] . ";dbname=" . $infoConnexion["database"] . ";charset=utf8", $infoConnexion["user"], $infoConnexion["password"]);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    public function getAllAnnonces()
    {
        $sql = $this->pdo->prepare("SELECT * from annonces");
        $sql->execute();
        $res = $sql->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    }

    public function ajouterAnnonces($title, $description, $location, $photo, $user_id, $date, $type_id, $postal_code)
    {



        $sql = $this->pdo->prepare("INSERT INTO `annonces`(`title`, `description`, `date`,`user_id`,`location`, `photo`,`type`,`post_code`) VALUES (:title, :description,:date, :user_id, :location, :photo, :type, :post_code)");
        $sql->bindParam(':title', $title, PDO::PARAM_STR);
        $sql->bindParam(':description', $description, PDO::PARAM_STR);
        $sql->bindParam(':date', $date, PDO::PARAM_STR);
        $sql->bindParam(':user_id', $user_id, PDO::PARAM_STR);
        $sql->bindParam(':location', $location, PDO::PARAM_STR);
        $sql->bindParam(':photo', $photo, PDO::PARAM_STR);
        $sql->bindParam(':type', $type_id, PDO::PARAM_STR);
        $sql->bindParam(':post_code', $postal_code, PDO::PARAM_STR);
        return $sql->execute();
    }

    public function getAnnonces($idType)
    {
        $sql = $this->pdo->prepare("SELECT *, id_Type
            FROM annonces
            INNER JOIN logement ON annonces.ID_Logements = logement.id WHERE id_Type = :idType;");
        $sql->bindParam(':idType', $idType, PDO::PARAM_INT);
        $sql->execute();
        $res = $sql->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    }

    public function getUneAnnonce($id)
    {
        $sql = $this->pdo->prepare("SELECT * FROM annonces WHERE id=:id");
        $sql->bindParam(':id', $id, PDO::PARAM_INT);
        $sql->execute();
        $res = $sql->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    }

    public function getIdLogementAnnonce($id)
    {
        $sql = $this->pdo->prepare("SELECT ID_Logements FROM annonces WHERE ID=:id");
        $sql->bindParam(':id', $id, PDO::PARAM_INT);
        $sql->execute();
        $res = $sql->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    }

    public function getAnnonceProprio($id)
    {
        $sql = $this->pdo->prepare("SELECT * FROM annonces WHERE ID_Utilisateurs=:id");
        $sql->bindParam(':id', $id, PDO::PARAM_INT);
        $sql->execute();
        $res = $sql->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    }

    public function updateAnnonce($id, $title, $description, $location, $image = null, $type_id = '', $postal_code)
    {
        $val = array();
        if ($image) {
            // $sql = $this->pdo->prepare("UPDATE `annonces` SET `title` = `$title`, `description`=`$description`, `location`= `$location`, `photo`=`$image`,`type`=`$type_id`, `post_code`=`$postal_code` WHERE `annonces`.`id` = `$id`");
            $sql = $this->pdo->prepare("UPDATE annonces SET `title` = :title, `description` = :description, `location` = :location, `post_code` = :postal_code,`type`=:type_id, `photo`=:photo WHERE `id` = :id");
            $val = array(
                ':id'=>$id,
                ':title' => $title,
                ':description' => $description,
                ':location' => $location,
                ':postal_code' => $postal_code,
                ':type_id' => $type_id,
                ':photo' => $image
            );
        } else {
            // $sql = $this->pdo->prepare('UPDATE `annonces` SET `title` = '.$title.', `description` = '.$description .', `location` = '.$location .',`type`='.$type_id.' `post_code` = '.$postal_code.' WHERE `annonces`.`id` = $id');
            $sql = $this->pdo->prepare("UPDATE annonces SET `title` = :title, `description` = :description, `location` = :location, `post_code` = :postal_code,`type`=:type_id WHERE `id` = :id");
            $val = array(
                ':id'=>$id,
                ':title' => $title,
                ':description' => $description,
                ':location' => $location,
                ':postal_code' => $postal_code,
                ':type_id' => $type_id
            );

        }
        return $sql->execute($val);
    }
    public function deleteanouncement($id)
    {
        $sql = $this->pdo->prepare("DELETE FROM `annonces` WHERE `annonces`.`id` = '$id'");
        return $sql->execute();
    }
    public function getByType($id)
    {
        $sql = $this->pdo->prepare("SELECT * FROM `annonces` WHERE `annonces`.`type` = '$id'");
        $sql->execute();
        $res = $sql->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    }

    public function search($postal_code){
        $sql = $this->pdo->prepare("SELECT * FROM annonces WHERE post_code LIKE '%$postal_code%'");
        $sql->execute();
        $res = $sql->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    }
}