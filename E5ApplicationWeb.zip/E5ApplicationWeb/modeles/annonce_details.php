<?php
require_once "controleurs/controleur.php";
$controleur = new controleur();

if(isset($_GET['id'])) {
    $idAnnonce = $_GET['id'];
    $controleur->afficherDetailsAnnonce($idAnnonce);
} else {
    header("Location: index.php?action=accueil");
    exit;
}
?>
