-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : ai117232-001.eu.clouddb.ovh.net:35835
-- Généré le : jeu. 16 mai 2024 à 16:51
-- Version du serveur : 10.11.7-MariaDB-1:10.11.7+maria~deb11-log
-- Version de PHP : 8.1.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `booking_system`
--

-- --------------------------------------------------------

--
-- Structure de la table `annonces`
--

CREATE TABLE `annonces` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `location` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `type` int(11) NOT NULL,
  `post_code` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `annonces`
--

INSERT INTO `annonces` (`id`, `title`, `description`, `date`, `user_id`, `location`, `photo`, `type`, `post_code`) VALUES
(62, 'Studio', 'Studio 22m2, chauffage électrique, meublé, wifi, salle de bain, clic clac, frigo, idéal personne seule ou étudiant', '2024-05-16', 46, 'Saint-Étienne 42100 ', 'image1715867591.jpg', 2, '42100'),
(63, 'Appartement T1 sur Bordeaux', 'A louer !\r\n\r\nBORDEAUX, quartier Xaintrailles,\r\n\r\nVenez découvrir cet appartement type 1, idéalement placé, proche des transports et des commerces !\r\n\r\nDisponible de suite !\r\n\r\nL’appartement de 30 m², au 4ème étage d’une copropriété avec ascenseur, se compose d’une entrée donnant sur une kitchenette (plaques au gaz), une pièce principale donnant sur un balcon et d’une salle de bains avec WC. L’appartement est lumineux.\r\nRésidence sécurisée avec ascenseur.\r\n\r\n« Zone soumise à encadrement des loyers » :\r\n- Le secteur géographique du bien se trouve dans la zone 2.\r\nLoyer de référence sur le secteur : 16.50 €/m²\r\nLoyer de référence majoré sur le secteur : 19.80 €/m²\r\n\r\nLoyer mensuel : 545 €\r\nProvisions de charges mensuelles (charges de copropriété et eau privative) : 55 €\r\nSoit un loyer CC de 600 €\r\n\r\nHonoraires à la charge du locataire : 390 € (dont 90 € pour les honoraires d’état des lieux)\r\n\r\nDépôt de garantie : 545 € ( soit un mois de loyers hors charges )\r\n\r\nDPE : E (318 kWhEP/m².an)\r\nGES : E (68 kgéqCO²/m².an)\r\nNouveau DPE valable jusqu’au 10/07/2033.\r\nEstimation du coût annuel en énergie pour un usage standard entre 740 et 1030 € TTC (Prix moyen des énergies indexées au 01/01/2021).\r\n\r\nConsommation énergie primaire : 318 kWhEP/m².an.\r\nConsommation énergie finale : 309 kWhEP/m².an.\r\n\r\nLes informations sur les risques auxquels ce bien est exposé sont disponibles sur le site Géorisques: www.georisques.gouv.fr\r\n\r\nContactez Emilie ou Oriane, BORDEAUX GESTION LOCATIVE\r\n\r\nRef interne : BDX032', '2024-05-16', 46, 'Bordeaux 33000 ', 'image1715867661.jpg', 1, '33000 '),
(64, 'Superbe T1 meublé 25m² Toulouse Montaudran', 'L’ agence Cgéré a le plaisir de vous proposer à la location dans une résidence propre et sécurisée, un appartement meublé T1 de 25m²\r\n\r\nCe logement dispose d’une entrée desservant une cuisine ouverte aménagée ( plaque vitrocéramique, hotte aspirante, réfrigérateur, ustensiles cuisine, couverts… ) donnant sur un séjour agréable et meublé avec goût, ainsi que d\'une salle d\'eau avec WC.\r\n\r\nLes plus : Idéalement situé, la résidence est situé près des transports menant à l\'université Paul Sabatier et autres écoles du secteur Rangueil et Labège.\r\n\r\n-Loyer mensuel charges comprises : 500€ (dont 50€ de provisions charges) ;\r\n-Modalité de récupération des charges locatives : prévisionnelles mensuelles avec régularisation annuelle ;\r\n-Honoraires de location : 325€ TTC (dont 73€ pour l\'état des lieux) ;\r\n-Dépôt de garantie : 900€ (deux mois de loyer hors charges) ;\r\n\r\n-Date de réalisation du diagnostic énergétique : en cours.', '2024-05-16', 46, '\r\nToulouse 31400 ', 'image1715867698.jpg', 1, '31400'),
(65, 'Superbe T3 meublé 63m² Côte Pavée / Cité de l\'Hers', 'TOULOUSE- Secteur Cote Pavée / Cité de l\'Hers (logement meublé)\r\n\r\nAu-delà d\'une situation géographique privilégiée, la qualité de vie du secteur s\'exprime par le dynamise commercial de l\'avenue de Castres, véritable axe offrant tous les services et commerces variés :\r\n\r\n- Des commerces de quartier à taille humaine (école, boulangerie, restaurants, épicerie, etc)\r\n\r\nCe secteur est apprécié pour offrir un cadre de vie paisible à deux pas des principaux axes routiers et de tous les moyens de transports écoresponsables en accès direct vers le centre de la ville rose :\r\n\r\n- Le périphérique à 2min\r\n- Ligne de bus au pied de la résidence.\r\n\r\nCe logement meublé de 63m² se compose d\'une entrée, séjour de 30m² avec cuisine ouverte entièrement équipée ouvrant sur un balcon de 8m².\r\nDeux chambres de 11 et 13m² avec placards de rangement, un cellier, une salle de bain de 7m² avec baignoire. (possibilité de faire installer un second lit double)\r\n\r\nUne place de stationnement accompagne ce logement.\r\n\r\n-Loyer mensuel charges comprises : 930€ (dont 70€ de provisions charges) ;\r\n-Modalité de récupération des charges locatives : prévisionnelles mensuelles avec régularisation annuelle ;\r\n-Honoraires de location : 819€ TTC (dont 186€ pour l\'état des lieux) ;\r\n-Dépôt de garantie : 1720€ (deux mois de loyer hors charges) ;\r\n\r\n-Date de réalisation du diagnostic énergétique : 01/03/2022.\r\n-Montant estimé des dépenses annuelles d\'énergie pour un usage standard : entre 360€ et 450€ par an abonnement compris. (Prix moyens des énergies indexés sur l\'année 2015).\r\n\r\n-Consommation énergie primaire : 47kWh/m²/an ;\r\n-Consommation énergie finale : Non communiquée.', '2024-05-16', 46, 'Toulouse 31500 ', 'image1715867782.jpg', 1, '31500'),
(66, 'Beau T2 rénové et meublé - Mulhouse', 'Adresse : 12 rue de Vittel, Mulhouse\r\n\r\nDescription :\r\n\r\nVenez découvrir ce magnifique T2 de 36m², entièrement refait à neuf, situé dans un quartier calme et une copropriété paisible à Mulhouse. Cet appartement lumineux et fonctionnel est prêt à vous accueillir avec une décoration moderne et élégante, pensée pour votre confort au quotidien.\r\n\r\nEn entrant, vous serez immédiatement séduit par l\'ambiance chaleureuse et conviviale de cet espace de vie. La cuisine ouverte est entièrement équipée avec des appareils électroménagers modernes, incluant une plaque de cuisson, un four, une hotte, un réfrigérateur et un congélateur. Vous y trouverez tout ce dont vous avez besoin !\r\n\r\nLa chambre est dotée d\'un lit double et d\'un espace dressing. Elle offre un espace de repos idéal, propice à de bonnes nuits de sommeil ! La salle de bain moderne est équipée d\'une douche moderne et d\'une machine à laver, ajoutant ainsi à la praticité de ce logement.\r\n\r\nLoyer : 530€ par mois\r\nMontant : 120€ par mois (incluant eau chaude, eau froide, chauffage et entretien des communs)\r\n\r\nHonoraires : 200€ TTC (visites, constitution du dossier, étude du dossier, rédaction du bail et état des lieux)\r\n\r\nPerformance Énergétique :\r\n\r\nDPE : Classe D (190 kWh/m²/an)\r\nGES : Classe D (39 kg CO2/m²/an)\r\n\r\nInformations supplémentaires :\r\nLes informations sur les risques auxquels ce bien est exposé sont disponibles sur le site Géorisques : www.georisques.gouv.fr\r\n\r\nContact :\r\nPour plus d\'informations ou pour planifier une visite, contactez-nous dès maintenant au [Coordonnées masquées]\r\n\r\nNe manquez pas cette opportunité !', '2024-05-16', 46, '12 rue de Vittel, Mulhouse Mulhouse 68100 \r\n· Quartier Bourtzwiller', 'image1715867820.jpg', 1, '68100'),
(67, 'Appartement T3 65,6 m2 Vannes - Rive gauche', 'A la lisière d’un parc, appartement neuf livré en juillet 2017, quartier PIBS1-Université, qui se compose d’une entrée avec placard, d’un séjour avec cuisine ouverte aménagée et équipée de 30 m² donnant sur une terrasse de 12 m² exposé S/O, de 2 chambres (12,9 m² et 9 m²) dont une avec placard, d’une salle de bains et d’un WC.\r\n- Cuisine aménagée et équipée (plaque vitrocéramique, hotte aspiration, four, micro ondes)\r\n- Chauffage et eau chaude au gaz\r\n- Terrasse, Interphone, local à vélos\r\n- 1 garage fermé en sous sol\r\n- 1 place de parking.\r\n\r\nConforme à la réglementation thermique RT 2012', '2024-05-16', 46, 'Vannes 56000 ', 'image1715867854.jpg', 1, '56000 '),
(69, 'Appartement à louer', 'Notre agence vous propose à la location un appartement de type T3 de 60 m² au R+1 , situé dans la résidence LE MUSCADIER à TSOUNDZOU II.\r\n\r\nIl se compose d\'une entrée, d\'un séjour climatisé, d\'une cuisine ouverte, de deux chambres climatisées, d\'une salle d\'eau, d\'un WC et d\'un cellier.\r\n\r\nL\'appartement dispose également d\'un balcon, d\'un jardin privatif ainsi que d\'une place de parking.', '2024-05-16', 49, 'à Mamoudzou (97600)', 'image1715869863.jpg', 1, '97600'),
(70, 'Appartement meublé à louer', 'Un appartement de type T3 meublé situé au R+2 de la résidence HAMEAU DU RECIF (avec piscine) à KOUNGOU, d\'une superficie habitable de 67.40 m² , comprenant :\r\nUne entrée, un séjour, une cuisine ouverte, un cellier, deux chambres, une salle d\'eau et un WC. Il dispose également d\'une terrasse de 13.50 m² et d\'un emplacement de parking couvert. Disponible de suite', '2024-05-16', 49, 'à Koungou (97600)', 'image1715870025.jpg', 1, '97600'),
(71, 'Appartement meublé à louer', 'de 71,58 m² , meublé au R.D.C .\r\n\r\nIl est composé d\'un salon spacieux et climatisé donnant accès à un espace vert collectif, une cuisine équipée et fonctionnelle (plaque four, hotte, micro-onde) , deux chambres climatisées , une salle de douche à l\'italienne, et un WC séparé .\r\nNe manquez pas cette occasion ! Contactez nous pour planifier une visite.', '2024-05-16', 49, 'à Koungou (97690)', 'image1715870111.jpg', 1, '97690');

-- --------------------------------------------------------

--
-- Structure de la table `home_type`
--

CREATE TABLE `home_type` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `home_type`
--

INSERT INTO `home_type` (`id`, `name`) VALUES
(1, 'Appartement'),
(2, 'Studio');

-- --------------------------------------------------------

--
-- Structure de la table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `annonces_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `start_date` varchar(255) NOT NULL,
  `end_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `reservations`
--

INSERT INTO `reservations` (`id`, `annonces_id`, `client_id`, `start_date`, `end_date`) VALUES
(19, 62, 48, '2024-05-17', '2024-05-20'),
(22, 71, 48, '2024-09-29', '2025-09-29');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `role` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`) VALUES
(46, 'd', 'd@gmail.com', '$2y$10$riMyPzJGgWqHcQ9l4k.Bv.k3iHYq7TtIW5XpJvH72UvupisGlMTQ.', 'employee'),
(47, 'c', 'c@gmail.com', '$2y$10$EPN.YtTHFLvjKpDC5s4d9eX/rZXPwsoi8s.vOo9JZmbE3sbgnKHzK', 'client'),
(48, 'Isaie-Dean', 'AhamadiIsaie@gmail.com', '$2y$10$YF6jxTaSObrqGIxW/C7j1ud7pHCgzrzYegOT.ZepRXro8Zwvdf.o2', 'client'),
(49, 'Baggy', 'AAhamadiIsaie@gmail.com', '$2y$10$1syrVFOUwKHnfUaOe4ORau7LYAFIIvQpCMmN436w9Pbiy/amjLnGm', 'employee');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `annonces`
--
ALTER TABLE `annonces`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `home_type`
--
ALTER TABLE `home_type`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `annonces`
--
ALTER TABLE `annonces`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT pour la table `home_type`
--
ALTER TABLE `home_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
